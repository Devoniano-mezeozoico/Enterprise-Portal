import re
import sqlite3
from datetime import time, timedelta

import pandas as pd

DB_PATH = "database/intranet.db"


def _conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _limpar_nome_coluna(coluna):
    return re.sub(r"\s+", " ", str(coluna or "")).strip().lower()


def _achar_coluna(colunas, candidatos):
    normalizadas = {col: _limpar_nome_coluna(col) for col in colunas}
    for col, nome in normalizadas.items():
        if all(candidato in nome for candidato in candidatos):
            return col
    return None


def _segundos_para_hhmmss(segundos):
    segundos = int(round(float(segundos or 0)))
    horas, resto = divmod(segundos, 3600)
    minutos, seg = divmod(resto, 60)
    return f"{horas:02d}:{minutos:02d}:{seg:02d}"


def _duracao_para_segundos(valor):
    if pd.isna(valor):
        return None
    if isinstance(valor, timedelta):
        return int(valor.total_seconds())
    if isinstance(valor, time):
        return valor.hour * 3600 + valor.minute * 60 + valor.second
    if isinstance(valor, (int, float)):
        if valor < 1:
            return int(round(valor * 24 * 3600))
        return int(round(valor))
    texto = str(valor).strip()
    if not texto or texto == "-":
        return None
    partes = texto.split(":")
    try:
        partes = [int(float(parte)) for parte in partes]
    except ValueError:
        return None
    if len(partes) == 3:
        return partes[0] * 3600 + partes[1] * 60 + partes[2]
    if len(partes) == 2:
        return partes[0] * 60 + partes[1]
    if len(partes) == 1:
        return partes[0]
    return None


def _processar_resultado_pronto(df):
    nome_col = _achar_coluna(df.columns, ["nome"]) or df.columns[0]
    depto_col = _achar_coluna(df.columns, ["departamento"])
    qtd_col = _achar_coluna(df.columns, ["qtd"]) or _achar_coluna(df.columns, ["atendimento"])
    tempo_col = _achar_coluna(df.columns, ["tempo"]) or _achar_coluna(df.columns, ["resposta"])
    if not depto_col or not qtd_col or not tempo_col:
        raise ValueError("Nao encontrei as colunas esperadas no resultado pronto.")
    linhas = []
    for _, row in df.iterrows():
        nome = str(row.get(nome_col, "")).strip()
        departamento = str(row.get(depto_col, "")).strip()
        qtd = pd.to_numeric(row.get(qtd_col), errors="coerce")
        segundos = _duracao_para_segundos(row.get(tempo_col))
        if not nome or nome.lower() == "nan" or pd.isna(qtd) or segundos is None:
            continue
        linhas.append({
            "nome": nome,
            "departamento": departamento or "Sem departamento",
            "qtd_atendimentos": int(qtd),
            "tempo_medio_segundos": int(segundos),
            "tempo_medio_formatado": _segundos_para_hhmmss(segundos),
        })
    return linhas


def _processar_bruto(df):
    responsavel_col = _achar_coluna(df.columns, ["respons"])
    departamento_col = _achar_coluna(df.columns, ["grupo", "respons"])
    tempo_col = _achar_coluna(df.columns, ["tempo", "espera"])
    if not responsavel_col or not departamento_col or not tempo_col:
        raise ValueError("Nao encontrei as colunas Responsavel, Grupo responsavel e Tempo de espera.")
    trabalho = df[[responsavel_col, departamento_col, tempo_col]].copy()
    trabalho.columns = ["nome", "departamento", "tempo"]
    trabalho["nome"] = trabalho["nome"].astype(str).str.strip()
    trabalho["departamento"] = trabalho["departamento"].astype(str).str.strip()
    trabalho["tempo_segundos"] = trabalho["tempo"].map(_duracao_para_segundos)
    trabalho = trabalho[(trabalho["nome"] != "") & (trabalho["nome"] != "-") & (trabalho["nome"].str.lower() != "nan") & trabalho["tempo_segundos"].notna()].copy()
    trabalho.loc[trabalho["departamento"].isin(["", "-", "nan", "NaN"]), "departamento"] = "Sem departamento"
    agrupado = trabalho.groupby(["nome", "departamento"], dropna=False).agg(qtd_atendimentos=("nome", "size"), tempo_medio_segundos=("tempo_segundos", "mean")).reset_index()
    agrupado["tempo_medio_segundos"] = agrupado["tempo_medio_segundos"].round().astype(int)
    agrupado["tempo_medio_formatado"] = agrupado["tempo_medio_segundos"].map(_segundos_para_hhmmss)
    agrupado = agrupado.sort_values(["tempo_medio_segundos", "qtd_atendimentos"], ascending=[False, False])
    return agrupado.to_dict("records")


def processar_planilha(caminho_arquivo):
    df = pd.read_excel(caminho_arquivo)
    colunas_norm = [_limpar_nome_coluna(c) for c in df.columns]
    parece_resultado = any("qtd" in c for c in colunas_norm) and any("tempo" in c for c in colunas_norm)
    linhas = _processar_resultado_pronto(df) if parece_resultado else _processar_bruto(df)
    tipo = "resultado" if parece_resultado else "bruto"
    if not linhas:
        raise ValueError("A planilha foi lida, mas nenhum atendimento valido foi encontrado.")
    return tipo, linhas


def salvar_metricas(linhas, arquivo_origem, tipo_origem):
    conn = _conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM atendimento_metricas")
    for linha in linhas:
        cur.execute(
            """INSERT INTO atendimento_metricas(nome,departamento,qtd_atendimentos,tempo_medio_segundos,tempo_medio_formatado,arquivo_origem,tipo_origem)
               VALUES(?,?,?,?,?,?,?)""",
            (linha["nome"], linha["departamento"], linha["qtd_atendimentos"], linha["tempo_medio_segundos"], linha["tempo_medio_formatado"], arquivo_origem, tipo_origem),
        )
    conn.commit()
    conn.close()


def listar_metricas():
    conn = _conn()
    rows = conn.execute("SELECT * FROM atendimento_metricas ORDER BY qtd_atendimentos DESC, tempo_medio_segundos DESC, nome").fetchall()
    conn.close()
    return rows


def _where_setor(setor):
    setor = str(setor or "").strip()
    if not setor:
        return "", ()
    return "WHERE lower(COALESCE(departamento, '')) = lower(?)", (setor,)


def top_qtd(limite=10, setor=None):
    conn = _conn()
    where, params = _where_setor(setor)
    rows = conn.execute(
        f"SELECT * FROM atendimento_metricas {where} ORDER BY qtd_atendimentos DESC, tempo_medio_segundos DESC LIMIT ?",
        (*params, limite),
    ).fetchall()
    conn.close()
    return rows


def top_tempo(limite=10, setor=None):
    conn = _conn()
    where, params = _where_setor(setor)
    prefixo = f"{where} AND" if where else "WHERE"
    rows = conn.execute(
        f"SELECT * FROM atendimento_metricas {prefixo} qtd_atendimentos > 0 ORDER BY tempo_medio_segundos DESC, qtd_atendimentos DESC LIMIT ?",
        (*params, limite),
    ).fetchall()
    conn.close()
    return rows


def resumo(setor=None):
    conn = _conn()
    where, params = _where_setor(setor)
    row = conn.execute(
        f"SELECT COUNT(*) AS pessoas, COALESCE(SUM(qtd_atendimentos), 0) AS total FROM atendimento_metricas {where}",
        params,
    ).fetchone()
    ultima = conn.execute(
        f"SELECT arquivo_origem, tipo_origem, atualizado_em FROM atendimento_metricas {where} ORDER BY atualizado_em DESC LIMIT 1",
        params,
    ).fetchone()
    conn.close()
    return {"pessoas": row["pessoas"], "total": row["total"], "ultima": ultima}
