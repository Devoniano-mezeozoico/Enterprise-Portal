﻿import importlib
import logging
import os
import secrets
import sqlite3
import time
import urllib.request
from datetime import date, datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path

from flask import (Flask, abort, flash, jsonify, redirect, render_template,
                   request, send_file, session, url_for)
from werkzeug.utils import secure_filename

from ai.ollama import perguntar_ia
from auth import (admin_required, login_required, recepcao_required,
                  superadmin_required, usuario_atual)
from database.models import agenda as agenda_model
from database.models import atendimentos as atendimentos_model
from database.models import chamados_ti as chamados_model
from database.models import chat as chat_model
from database.models import estoque_ti as estoque_model
from database.models import hub_apps as hub_model
from database.models import honeypot_fake as honeypot_fake_model
from database.models import noticias as noticias_model
from database.models import pops as pops_model
from database.models import usuarios as usuarios_model

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "gumz_intranet_2026")

DB_PATH = "database/intranet.db"
LOG_DIR = "logs"
os.makedirs(LOG_DIR, exist_ok=True)

_fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
_fh = RotatingFileHandler(os.path.join(LOG_DIR,"app.log"), maxBytes=5*1024*1024, backupCount=5, encoding="utf-8")
_fh.setFormatter(_fmt)
_ch = logging.StreamHandler()
_ch.setFormatter(_fmt)
logging.basicConfig(level=logging.INFO, handlers=[_fh, _ch])

CATEGORIAS_POP = ["Fiscal","RH","Administrativo","TI","Operacional","Segurança","Qualidade","Comercial","Outros"]
ROTAS_PUBLICAS = {"login", "static", "admin_painel"}
_PAIS_IP_CACHE = {}

# ── TABELAS ────────────────────────────────────────────────
def criar_tabelas():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    c.execute("""CREATE TABLE IF NOT EXISTS acessos(
        id INTEGER PRIMARY KEY AUTOINCREMENT, ip TEXT, hostname TEXT,
        pagina TEXT, navegador TEXT, pais TEXT,
        data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    c.execute("PRAGMA table_info(acessos)")
    colunas_acessos = {linha[1] for linha in c.fetchall()}
    if "pais" not in colunas_acessos:
        c.execute("ALTER TABLE acessos ADD COLUMN pais TEXT")

    c.execute("""CREATE TABLE IF NOT EXISTS salas(
        id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL UNIQUE,
        capacidade INTEGER DEFAULT 0, descricao TEXT)""")

    c.execute("""CREATE TABLE IF NOT EXISTS reservas(
        id INTEGER PRIMARY KEY AUTOINCREMENT, sala_id INTEGER NOT NULL,
        titulo TEXT NOT NULL, responsavel TEXT NOT NULL,
        data_reserva DATE NOT NULL, hora_inicio TIME NOT NULL, hora_fim TIME NOT NULL,
        observacao TEXT, criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(sala_id) REFERENCES salas(id))""")

    c.execute("""CREATE TABLE IF NOT EXISTS usuarios(
        id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE, senha_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'comum', setor TEXT,
        ativo INTEGER NOT NULL DEFAULT 1,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP)""")

    c.execute("""CREATE TABLE IF NOT EXISTS noticias(
        id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT NOT NULL,
        resumo TEXT, conteudo TEXT, autor TEXT,
        caminho_anexo TEXT, nome_anexo TEXT,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP)""")

    c.execute("""CREATE TABLE IF NOT EXISTS eventos_agenda(
        id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT NOT NULL,
        descricao TEXT, data_evento DATE NOT NULL,
        hora_inicio TIME, hora_fim TIME,
        tipo TEXT NOT NULL DEFAULT 'reserva',
        sala TEXT NOT NULL DEFAULT 'Geral',
        criado_por TEXT,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP)""")
    c.execute("PRAGMA table_info(eventos_agenda)")
    colunas_eventos = {linha[1] for linha in c.fetchall()}
    if "tipo" not in colunas_eventos:
        c.execute("ALTER TABLE eventos_agenda ADD COLUMN tipo TEXT NOT NULL DEFAULT 'reserva'")

    c.execute("""CREATE TABLE IF NOT EXISTS pops(
        id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT NOT NULL,
        categoria TEXT DEFAULT 'Geral', nome_arquivo TEXT NOT NULL,
        caminho_arquivo TEXT NOT NULL, conteudo_texto TEXT,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP)""")

    c.execute("""CREATE TABLE IF NOT EXISTS hub_apps(
        id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL,
        descricao TEXT, icone TEXT DEFAULT 'fa-solid fa-mobile-screen',
        url TEXT NOT NULL, setor TEXT NOT NULL DEFAULT 'Geral',
        setores_liberados TEXT,
        ativo INTEGER NOT NULL DEFAULT 1,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP)""")
    c.execute("PRAGMA table_info(hub_apps)")
    colunas_hub_apps = {linha[1] for linha in c.fetchall()}
    if "setores_liberados" not in colunas_hub_apps:
        c.execute("ALTER TABLE hub_apps ADD COLUMN setores_liberados TEXT")
    c.execute("UPDATE hub_apps SET setores_liberados = setor WHERE setores_liberados IS NULL OR TRIM(setores_liberados) = ''")

    c.execute("""CREATE TABLE IF NOT EXISTS chamados_ti(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        usuario_nome TEXT NOT NULL,
        titulo TEXT NOT NULL,
        descricao TEXT NOT NULL,
        prioridade TEXT DEFAULT 'normal',
        status TEXT NOT NULL DEFAULT 'aberto',
        responsavel TEXT,
        resposta TEXT,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
        respondido_em DATETIME,
        resolvido_em DATETIME,
        atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(usuario_id) REFERENCES usuarios(id))""")

    c.execute("""CREATE TABLE IF NOT EXISTS estoque_ti(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        categoria TEXT NOT NULL DEFAULT 'Perifericos',
        quantidade INTEGER NOT NULL DEFAULT 0,
        localizacao TEXT,
        observacao TEXT,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
        atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP)""")

    c.execute("""CREATE TABLE IF NOT EXISTS chat_mensagens(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        usuario_nome TEXT NOT NULL,
        mensagem TEXT NOT NULL,
        apagada INTEGER NOT NULL DEFAULT 0,
        apagada_em DATETIME,
        apagada_por_id INTEGER,
        apagada_por_nome TEXT,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(usuario_id) REFERENCES usuarios(id))""")

    c.execute("""CREATE TABLE IF NOT EXISTS atendimento_metricas(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        departamento TEXT,
        qtd_atendimentos INTEGER NOT NULL DEFAULT 0,
        tempo_medio_segundos INTEGER NOT NULL DEFAULT 0,
        tempo_medio_formatado TEXT,
        arquivo_origem TEXT,
        tipo_origem TEXT,
        atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP)""")

    c.execute("""CREATE TABLE IF NOT EXISTS honeypot_tentativas(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip TEXT,
        pais TEXT,
        rota TEXT,
        caminho_completo TEXT,
        metodo TEXT,
        email_tentado TEXT,
        senha_len INTEGER DEFAULT 0,
        user_agent TEXT,
        referer TEXT,
        nivel TEXT,
        motivo TEXT,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP)""")

    # Seeds
    c.execute("SELECT COUNT(*) FROM salas")
    if c.fetchone()[0] == 0:
        c.executemany("INSERT INTO salas(nome,capacidade) VALUES(?,?)",[
            ("Sala Reunião 01",8),("Sala Reunião 02",8),
            ("Sala Diretoria",12),("Sala Treinamento",30)])

    c.execute("SELECT COUNT(*) FROM hub_apps")
    if c.fetchone()[0] == 0:
        apps_seed = [
            ("Dashboard Fiscal","Indicadores e conferências fiscais (SAT, CT-e, NF-e).",
             "fa-solid fa-file-invoice-dollar","/apps/fiscal/dashboard","Fiscal"),
            ("Reserva de Salas","Agende salas de reunião da empresa.",
             "fa-solid fa-calendar-days","/reservas","Administrativo"),
            ("Gerador de RPA","Cria scripts de automação a partir de uma lista de passos.",
             "fa-solid fa-robot","/apps/gerador_rpa/","Automações"),
            ("Treinamentos","Trilhas de treinamento e capacitação dos colaboradores.",
             "fa-solid fa-graduation-cap","/apps/rh/treinamentos","RH"),
            ("Gerador RPA - Autônomos","Gera TXT de importação de autônomos a partir da planilha de contratos.",
             "fa-solid fa-file-export","/apps/autonomo_rpa/","Automações"),
        ]
        c.executemany(
            "INSERT INTO hub_apps(nome,descricao,icone,url,setor,setores_liberados) VALUES(?,?,?,?,?,?)",
            [(nome, desc, icone, url, setor, setor) for nome, desc, icone, url, setor in apps_seed])

    c.execute("SELECT COUNT(*) FROM hub_apps WHERE lower(nome) = lower(?)", ("ADF",))
    if c.fetchone()[0] == 0:
        c.execute(
            "INSERT INTO hub_apps(nome,descricao,icone,url,setor,setores_liberados) VALUES(?,?,?,?,?,?)",
            (
                "ADF",
                "Acesso ao sistema ADF.",
                "fa-solid fa-diagram-project",
                os.environ.get("ADF_URL", "").strip() or "/apps/adf",
                "Geral",
                "Todos",
            )
        )

    conn.commit()
    conn.close()

# ── BOOTSTRAP SUPERADMIN ───────────────────────────────────
def bootstrap_superadmin():
    if usuarios_model.contar_usuarios() > 0:
        return
    senha = secrets.token_urlsafe(9)
    usuarios_model.criar_usuario("Administrador","admin@gumz.local",senha,"superadmin","TI")
    mensagem = f"Superadmin criado -> admin@gumz.local | Senha tempor\u00e1ria: {senha}"
    logging.warning(mensagem)
    try:
        with open(os.path.join(LOG_DIR, "app.log"), "a", encoding="utf-8") as f:
            f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | WARNING | {mensagem}\n")
    except Exception:
        pass

# ── CARREGAR BLUEPRINTS ───────────────────────────────────
def carregar_apps():
    apps_dir = Path("apps")
    if not apps_dir.exists():
        return
    for pasta in apps_dir.iterdir():
        if not pasta.is_dir() or pasta.name.startswith("__"):
            continue
        try:
            modulo = importlib.import_module(f"apps.{pasta.name}")
            if hasattr(modulo, "bp"):
                app.register_blueprint(modulo.bp)
                logging.info(f"Blueprint: {pasta.name}")
        except Exception as e:
            logging.error(f"Erro carregando {pasta.name}: {e}")

# ── BEFORE REQUEST ────────────────────────────────────────
def _obter_ip():
    ip = request.headers.get("X-Forwarded-For", request.remote_addr) or ""
    return ip.split(",")[0].strip() or "desconhecido"

def _pais_do_ip(ip):
    if not ip or ip in ("desconhecido", "127.0.0.1", "::1", "localhost"):
        return "Local"
    if ip.startswith(("10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.", "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.", "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31.")):
        return "Rede local"
    if ip in _PAIS_IP_CACHE:
        return _PAIS_IP_CACHE[ip]
    pais = "N/A"
    try:
        with urllib.request.urlopen(f"https://ipapi.co/{ip}/country_name/", timeout=1.5) as resp:
            texto = resp.read().decode("utf-8", errors="ignore").strip()
            if texto and "error" not in texto.lower():
                pais = texto[:80]
    except Exception:
        pass
    _PAIS_IP_CACHE[ip] = pais
    return pais

def _log_login(tipo, email):
    ip = _obter_ip()
    linha = f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {tipo} | {email} | {ip} | {_pais_do_ip(ip)}\n"
    try:
        with open(os.path.join(LOG_DIR,"logins.txt"),"a",encoding="utf-8") as f:
            f.write(linha)
    except Exception as e:
        logging.error(f"Erro logins.txt: {e}")

def _log_chat(acao, usuario, mensagem=None):
    texto = ""
    if mensagem is not None:
        texto = str(mensagem).replace("\r", " ").replace("\n", " ")
    linha = (
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {acao} | "
        f"id={usuario['id'] if usuario else 'N/A'} | "
        f"nome={usuario['nome'] if usuario else 'N/A'} | mensagem={texto}\n"
    )
    try:
        with open(os.path.join(LOG_DIR, "chat.log"), "a", encoding="utf-8") as f:
            f.write(linha)
    except Exception as e:
        logging.error(f"Erro chat.log: {e}")

def _classificar_honeypot(ip, rota, email_tentado, senha_texto, user_agent, referer, tentativas_ip):
    texto = f"{rota} {email_tentado} {senha_texto} {user_agent} {referer}".lower()
    ferramentas = ("ffuf", "gobuster", "dirsearch", "nikto", "nuclei", "sqlmap", "curl", "wget", "python-requests", "masscan", "zgrab")
    payloads = ("union select", "../", "<script", "sleep(", "benchmark(", "' or", "\" or", "${jndi", ".env", "passwd", "cmd=")
    credenciais_fracas = ("admin", "root", "teste", "test", "123", "senha", "password", "qwerty")

    if any(item in texto for item in ferramentas):
        return "script_kiddie", "User-Agent ou assinatura de ferramenta automatizada."
    if any(item in texto for item in payloads):
        return "senior", "Tentativa com payload de exploracao/injecao."
    if tentativas_ip >= 15:
        return "senior", "Volume alto de tentativas no honeypot."
    if tentativas_ip >= 6:
        return "medio", "Persistencia acima do normal para o mesmo IP."
    if any(item in texto for item in credenciais_fracas):
        return "baixo", "Tentativa com usuario/senha comuns."
    if "mozilla" in (user_agent or "").lower() and not referer and tentativas_ip <= 2:
        return "baixo", "Acesso manual inicial sem referer."
    return "medio", "Tentativa em rota administrativa falsa."


def _registrar_alerta_honeypot(ip, pais, tentativas_ip, nivel, motivo):
    if tentativas_ip not in (5, 10, 15, 20) and tentativas_ip % 25 != 0:
        return
    linha = (
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | ALERTA | "
        f"IP={ip} | PAIS={pais} | TENTATIVAS={tentativas_ip} | NIVEL={nivel} | MOTIVO={motivo}\n"
    )
    try:
        with open(os.path.join(LOG_DIR, "honeypot_alertas.log"), "a", encoding="utf-8") as f:
            f.write(linha)
    except Exception as e:
        logging.error(f"Erro honeypot_alertas.log: {e}")
    logging.warning(linha.strip())


def _log_honeypot_admin_painel(email_tentado="", senha_texto=""):
    ip = _obter_ip()
    pais = _pais_do_ip(ip)
    user_agent = request.headers.get("User-Agent", "")
    referer = request.headers.get("Referer", "")
    caminho_completo = request.full_path if request.query_string else request.path
    senha_len = len(senha_texto or "")

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    tentativas_ip = conn.execute("SELECT COUNT(*) FROM honeypot_tentativas WHERE ip=?", (ip,)).fetchone()[0] + 1
    nivel, motivo = _classificar_honeypot(ip, request.path, email_tentado, senha_texto, user_agent, referer, tentativas_ip)
    conn.execute(
        """
        INSERT INTO honeypot_tentativas
        (ip, pais, rota, caminho_completo, metodo, email_tentado, senha_len, user_agent, referer, nivel, motivo)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (ip, pais, request.path, caminho_completo, request.method, email_tentado, senha_len, user_agent, referer, nivel, motivo),
    )
    conn.commit()
    conn.close()

    linha = (
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | "
        f"IP={ip} | PAIS={pais} | TENTATIVAS_IP={tentativas_ip} | "
        f"NIVEL={nivel} | MOTIVO={motivo} | ROTA={request.path} | "
        f"CAMINHO={caminho_completo} | METODO={request.method} | "
        f"EMAIL={email_tentado or '-'} | SENHA_LEN={senha_len} | "
        f"REFERER={referer or '-'} | USER_AGENT={user_agent}\n"
    )
    try:
        with open(os.path.join(LOG_DIR, "honeypot_admin_painel.log"), "a", encoding="utf-8") as f:
            f.write(linha)
    except Exception as e:
        logging.error(f"Erro honeypot_admin_painel.log: {e}")
    _registrar_alerta_honeypot(ip, pais, tentativas_ip, nivel, motivo)
    return tentativas_ip, nivel, motivo

import socket as _socket

@app.before_request
def registrar_acesso():
    try:
        ip = _obter_ip()
        try: hostname = _socket.gethostbyaddr(ip)[0]
        except: hostname = "N/A"
        pais = _pais_do_ip(ip)
        conn = sqlite3.connect(DB_PATH)
        conn.execute("INSERT INTO acessos(ip,hostname,pagina,navegador,pais) VALUES(?,?,?,?,?)",
                     (ip, hostname, request.path, request.headers.get("User-Agent",""), pais))
        conn.commit(); conn.close()
    except Exception as e:
        logging.error(f"Erro acesso: {e}")

@app.before_request
def exigir_login():
    ep = request.endpoint
    if request.path.startswith("/admin_painel"):
        return
    if not ep or ep in ROTAS_PUBLICAS or ep.startswith("static"):
        return
    if not session.get("usuario_id"):
        if request.path.startswith("/api/"):
            return jsonify(erro="Não autenticado."), 401
        return redirect(url_for("login", proximo=request.path))

@app.context_processor
def injetar_usuario():
    return dict(usuario_logado=usuario_atual())

# ══════════════════════════════════════════════════════════
# ROTAS
# ══════════════════════════════════════════════════════════

# ── AUTH ──────────────────────────────────────────────────
@app.route("/admin", methods=["GET", "POST"])
@app.route("/painel", methods=["GET", "POST"])
@app.route("/wp-admin", methods=["GET", "POST"])
@app.route("/phpmyadmin", methods=["GET", "POST"])
@app.route("/admin_painel", methods=["GET", "POST"])
def admin_painel():
    email_tentado = request.form.get("email", "").strip() if request.method == "POST" else ""
    senha_texto = request.form.get("senha", "") if request.method == "POST" else ""
    if request.method == "POST":
        time.sleep(1.5)
    _log_honeypot_admin_painel(email_tentado, senha_texto)
    honeypot_fake_model.registrar(_obter_ip(), request.headers.get("User-Agent", ""), request.path, "login_submit" if request.method == "POST" else "login_view", email_tentado)

    erro = request.method == "POST"
    titulos = {
        "/admin": "Admin",
        "/painel": "Painel Administrativo",
        "/wp-admin": "WordPress Admin",
        "/phpmyadmin": "phpMyAdmin",
        "/admin_painel": "Admin Painel",
    }
    titulo = titulos.get(request.path, "Admin Painel")
    if request.method == "POST" and email_tentado and senha_texto:
        session["honeypot_fake_user"] = email_tentado
        return redirect(url_for("honeypot_dashboard"))
    return render_template("honeypot/login.html", titulo=titulo, erro=erro), 200


def _fake_user():
    return session.get("honeypot_fake_user") or "admin@gumz.local"


def _fake_track(acao, detalhe=""):
    honeypot_fake_model.registrar(_obter_ip(), request.headers.get("User-Agent", ""), request.path, acao, detalhe)


@app.route("/admin_painel/dashboard")
def honeypot_dashboard():
    if not session.get("honeypot_fake_user"):
        return redirect(url_for("admin_painel"))
    _log_honeypot_admin_painel(session.get("honeypot_fake_user"), "")
    _fake_track("view_dashboard")
    return render_template("honeypot/dashboard.html", dados=honeypot_fake_model.dashboard(), fake_user=_fake_user(), titulo="Dashboard")


@app.route("/admin_painel/users")
def honeypot_users():
    if not session.get("honeypot_fake_user"):
        return redirect(url_for("admin_painel"))
    _log_honeypot_admin_painel(session.get("honeypot_fake_user"), "")
    _fake_track("view_users")
    return render_template(
        "honeypot/table.html",
        titulo="Usuarios",
        subtitulo="Usuarios administrativos e contas de servico.",
        fake_user=_fake_user(),
        linhas=honeypot_fake_model.listar("users"),
        colunas=["ID", "Nome", "E-mail", "Role", "Status", "Ultimo login"],
        chaves=["id", "nome", "email", "role", "status", "ultimo_login"],
    )


@app.route("/admin_painel/tickets")
def honeypot_tickets():
    if not session.get("honeypot_fake_user"):
        return redirect(url_for("admin_painel"))
    _log_honeypot_admin_painel(session.get("honeypot_fake_user"), "")
    _fake_track("view_tickets")
    return render_template(
        "honeypot/table.html",
        titulo="Tickets",
        subtitulo="Fila operacional do painel administrativo.",
        fake_user=_fake_user(),
        linhas=honeypot_fake_model.listar("tickets"),
        colunas=["ID", "Titulo", "Cliente", "Prioridade", "Status", "Responsavel", "Criado em"],
        chaves=["id", "titulo", "cliente", "prioridade", "status", "responsavel", "criado_em"],
    )


@app.route("/admin_painel/logs")
def honeypot_logs():
    if not session.get("honeypot_fake_user"):
        return redirect(url_for("admin_painel"))
    _log_honeypot_admin_painel(session.get("honeypot_fake_user"), "")
    _fake_track("view_logs")
    return render_template(
        "honeypot/table.html",
        titulo="Logs",
        subtitulo="Eventos recentes do ambiente administrativo.",
        fake_user=_fake_user(),
        linhas=honeypot_fake_model.listar("logs"),
        colunas=["ID", "Nivel", "Origem", "Mensagem", "Criado em"],
        chaves=["id", "nivel", "origem", "mensagem", "criado_em"],
    )


@app.route("/admin_painel/backups")
def honeypot_backups():
    if not session.get("honeypot_fake_user"):
        return redirect(url_for("admin_painel"))
    _log_honeypot_admin_painel(session.get("honeypot_fake_user"), "")
    _fake_track("view_backups")
    return render_template(
        "honeypot/table.html",
        titulo="Backups",
        subtitulo="Arquivos de backup disponiveis para recuperacao.",
        fake_user=_fake_user(),
        linhas=honeypot_fake_model.listar("backups"),
        colunas=["ID", "Arquivo", "Tamanho", "Status", "Criado em"],
        chaves=["id", "arquivo", "tamanho", "status", "criado_em"],
    )


@app.route("/admin_painel/database", methods=["GET", "POST"])
def honeypot_database():
    if not session.get("honeypot_fake_user"):
        return redirect(url_for("admin_painel"))
    _log_honeypot_admin_painel(session.get("honeypot_fake_user"), request.form.get("acao", ""))
    _fake_track("database_action" if request.method == "POST" else "view_database", request.form.get("acao", ""))
    return render_template("honeypot/database.html", fake_user=_fake_user(), titulo="Database", erro=request.method == "POST")


@app.route("/admin_painel/logout")
def honeypot_logout():
    _fake_track("logout", session.get("honeypot_fake_user", ""))
    session.pop("honeypot_fake_user", None)
    return redirect(url_for("admin_painel"))

@app.route("/login", methods=["GET","POST"])
def login():
    if session.get("usuario_id"):
        return redirect(url_for("home"))
    if request.method == "POST":
        email = request.form.get("email","").strip()
        senha = request.form.get("senha","")
        u = usuarios_model.buscar_usuario_por_email(email)
        if not u or not u["ativo"] or not usuarios_model.verificar_senha(u, senha):
            _log_login("FALHA", email)
            flash("E-mail ou senha inválidos.", "erro")
            return redirect(url_for("login"))
        _log_login("SUCESSO", email)
        session["usuario_id"] = u["id"]
        return redirect(request.args.get("proximo") or url_for("home"))
    return render_template("login.html")

@app.route("/logout", methods=["POST"])
def logout():
    u = usuario_atual()
    if u: _log_login("LOGOUT", u["email"])
    session.clear()
    flash("Você saiu.", "sucesso")
    return redirect(url_for("login"))

# ── HOME ──────────────────────────────────────────────────
@app.route("/")
def home():
    u = usuario_atual()
    setor_usuario = (u["setor"] or "").strip() if u else ""
    if setor_usuario:
        atendimento_top_qtd = atendimentos_model.top_qtd(10, setor_usuario)
        atendimento_top_tempo = atendimentos_model.top_tempo(10, setor_usuario)
        atendimento_resumo = atendimentos_model.resumo(setor_usuario)
    else:
        atendimento_top_qtd = []
        atendimento_top_tempo = []
        atendimento_resumo = {"pessoas": 0, "total": 0, "ultima": None}
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    agenda_hoje = conn.execute(
        """
        SELECT * FROM eventos_agenda
        WHERE date(data_evento) = ? AND COALESCE(tipo, 'reserva') = 'reserva'
        ORDER BY sala, hora_inicio, titulo
        """,
        (date.today().isoformat(),)
    ).fetchall()
    conn.close()
    return render_template("index.html",
        total_apps=hub_model.contar_apps(u),
        total_pops=pops_model.contar_pops(),
        total_usuarios=usuarios_model.contar_usuarios(),
        noticias=noticias_model.listar_noticias(limite=5),
        pops_recentes=pops_model.listar_pops()[:6],
        agenda_hoje=agenda_hoje,
        proximos_eventos_gumz=agenda_model.proximos_eventos_internos(5),
        atendimento_top_qtd=atendimento_top_qtd,
        atendimento_top_tempo=atendimento_top_tempo,
        atendimento_resumo=atendimento_resumo,
        setor_indicadores=setor_usuario or "Sem setor",
        apps_hub=hub_model.listar_apps_para_usuario(u, apenas_ativos=True)[:6]
    )

# ── CHAT ─────────────────────────────────────────────────
@app.route("/chat", methods=["GET", "POST"])
def chat():
    u = usuario_atual()
    if request.method == "POST":
        mensagem = request.form.get("mensagem", "").strip()
        if not mensagem:
            flash("Digite uma mensagem antes de enviar.", "erro")
            return redirect(url_for("chat"))
        chat_model.criar_mensagem(u["id"], u["nome"], mensagem)
        _log_chat("ENVIO", u, mensagem)
        return redirect(url_for("chat"))

    pode_ver_apagadas = u and u["role"] in ("admin", "superadmin")
    mensagens = chat_model.listar_mensagens(incluir_apagadas=pode_ver_apagadas)
    return render_template("chat.html", mensagens=mensagens, pode_ver_apagadas=pode_ver_apagadas)

def _chat_msg_json(msg):
    return {
        "id": msg["id"],
        "usuario_id": msg["usuario_id"],
        "usuario_nome": msg["usuario_nome"],
        "mensagem": msg["mensagem"],
        "apagada": bool(msg["apagada"]),
        "apagada_em": msg["apagada_em"],
        "apagada_por_nome": msg["apagada_por_nome"],
        "criado_em": msg["criado_em"],
    }

@app.route("/api/chat/mensagens")
def api_chat_mensagens():
    u = usuario_atual()
    pode_ver_apagadas = u and u["role"] in ("admin", "superadmin")
    mensagens = chat_model.listar_mensagens(incluir_apagadas=pode_ver_apagadas)
    return jsonify(
        mensagens=[_chat_msg_json(m) for m in mensagens],
        usuario={"id": u["id"], "nome": u["nome"], "role": u["role"]},
        pode_ver_apagadas=pode_ver_apagadas,
    )

@app.route("/api/chat/enviar", methods=["POST"])
def api_chat_enviar():
    u = usuario_atual()
    dados = request.get_json(silent=True) or {}
    mensagem = (dados.get("mensagem") or "").strip()
    if not mensagem:
        return jsonify(sucesso=False, erro="Mensagem vazia."), 400
    mid = chat_model.criar_mensagem(u["id"], u["nome"], mensagem)
    _log_chat("ENVIO", u, mensagem)
    msg = chat_model.buscar_mensagem(mid)
    return jsonify(sucesso=True, mensagem=_chat_msg_json(msg))

@app.route("/chat/<int:mid>/apagar", methods=["POST"])
def chat_apagar(mid):
    u = usuario_atual()
    msg = chat_model.buscar_mensagem(mid)
    if not msg:
        abort(404)
    pode_apagar = (msg["usuario_id"] == u["id"]) or u["role"] in ("admin", "superadmin")
    if not pode_apagar:
        flash("Voce so pode apagar suas proprias mensagens.", "erro")
        return redirect(url_for("chat"))
    if not msg["apagada"]:
        chat_model.apagar_mensagem(mid, u["id"], u["nome"])
        _log_chat("APAGOU", u, f"id={mid} | autor={msg['usuario_nome']} | original={msg['mensagem']}")
    return redirect(url_for("chat"))

@app.route("/api/chat/<int:mid>/apagar", methods=["POST"])
def api_chat_apagar(mid):
    u = usuario_atual()
    msg = chat_model.buscar_mensagem(mid)
    if not msg:
        return jsonify(sucesso=False, erro="Mensagem nao encontrada."), 404
    pode_apagar = (msg["usuario_id"] == u["id"]) or u["role"] in ("admin", "superadmin")
    if not pode_apagar:
        return jsonify(sucesso=False, erro="Permissao insuficiente."), 403
    if not msg["apagada"]:
        chat_model.apagar_mensagem(mid, u["id"], u["nome"])
        _log_chat("APAGOU", u, f"id={mid} | autor={msg['usuario_nome']} | original={msg['mensagem']}")
    return jsonify(sucesso=True)

# ── NOTÍCIAS ─────────────────────────────────────────────
@app.route("/noticias")
def noticias():
    return render_template("noticias.html", noticias=noticias_model.listar_noticias())

@app.route("/noticias/<int:nid>")
def noticia_detalhe(nid):
    noticia = noticias_model.buscar_noticia_por_id(nid)
    if not noticia: abort(404)
    ext = Path(noticia["nome_anexo"] or "").suffix.lower()
    anexo_eh_imagem = ext in (".png", ".jpg", ".jpeg", ".gif", ".webp")
    return render_template("noticia_detalhe.html", noticia=noticia, anexo_eh_imagem=anexo_eh_imagem)

@app.route("/noticias/criar", methods=["POST"])
@admin_required
def noticias_criar():
    titulo   = request.form.get("titulo","").strip()
    resumo   = request.form.get("resumo","").strip()
    conteudo = request.form.get("conteudo","").strip()
    if not titulo:
        flash("Informe o título.", "erro")
        return redirect(url_for("noticias"))

    caminho_anexo = nome_anexo = None
    arquivo = request.files.get("anexo")
    if arquivo and arquivo.filename:
        pasta = Path("static/uploads/noticias")
        pasta.mkdir(parents=True, exist_ok=True)
        nome_seg = f"{int(time.time())}_{secure_filename(arquivo.filename)}"
        caminho = pasta / nome_seg
        arquivo.save(caminho)
        caminho_anexo = str(caminho)
        nome_anexo    = arquivo.filename

    u = usuario_atual()
    noticias_model.criar_noticia(titulo, resumo, conteudo, u["nome"] if u else "Admin",
                                  caminho_anexo, nome_anexo)
    flash("Notícia publicada!", "sucesso")
    return redirect(url_for("noticias"))

@app.route("/noticias/<int:nid>/anexo")
def noticias_anexo(nid):
    n = noticias_model.buscar_noticia_por_id(nid)
    if not n or not n["caminho_anexo"]: abort(404)
    return send_file(n["caminho_anexo"], as_attachment=True, download_name=n["nome_anexo"])

@app.route("/noticias/<int:nid>/midia")
def noticias_midia(nid):
    n = noticias_model.buscar_noticia_por_id(nid)
    if not n or not n["caminho_anexo"]: abort(404)
    ext = Path(n["nome_anexo"] or "").suffix.lower()
    if ext not in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
        abort(404)
    return send_file(n["caminho_anexo"])

@app.route("/noticias/<int:nid>/excluir", methods=["POST"])
@admin_required
def noticias_excluir(nid):
    noticias_model.excluir_noticia(nid)
    flash("Notícia removida.", "sucesso")
    return redirect(url_for("noticias"))

# ── AGENDA ──────────────────────────────────────────────
@app.route("/agenda")
def agenda():
    hoje = date.today()
    ano  = request.args.get("ano",  type=int) or hoje.year
    mes  = request.args.get("mes",  type=int) or hoje.month
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    salas = [r["nome"] for r in conn.execute("SELECT nome FROM salas ORDER BY nome").fetchall()]
    eventos_proximos = conn.execute(
        """
        SELECT * FROM eventos_agenda
        WHERE date(data_evento) >= date('now')
        ORDER BY sala, data_evento, hora_inicio
        LIMIT 60
        """
    ).fetchall()
    conn.close()
    eventos_por_sala = {}
    for evento in eventos_proximos:
        eventos_por_sala.setdefault(evento["sala"], []).append(evento)
    return render_template("agenda.html", ano=ano, mes=mes, salas=salas, eventos_por_sala=eventos_por_sala)

@app.route("/api/agenda/eventos")
def api_agenda_eventos():
    ano = request.args.get("ano", type=int)
    mes = request.args.get("mes", type=int)
    if not ano or not mes:
        return jsonify(erro="Parâmetros obrigatórios."), 400
    eventos = agenda_model.listar_eventos_mes(ano, mes)
    dados = [{
        "id": e["id"], "titulo": e["titulo"], "descricao": e["descricao"],
        "data": e["data_evento"], "hora_inicio": e["hora_inicio"],
        "hora_fim": e["hora_fim"], "sala": e["sala"],
        "tipo": e["tipo"] if "tipo" in e.keys() else "reserva",
        "cor": agenda_model.cor_do_evento(e["tipo"] if "tipo" in e.keys() else "reserva", e["sala"]),
        "criado_por": e["criado_por"],
    } for e in eventos]
    return jsonify(eventos=dados)

@app.route("/agenda/criar", methods=["POST"])
@recepcao_required
def agenda_criar():
    titulo      = request.form.get("titulo","").strip()
    descricao   = request.form.get("descricao","").strip()
    data_evento = request.form.get("data","").strip()
    hora_inicio = request.form.get("hora_inicio","").strip() or None
    hora_fim    = request.form.get("hora_fim","").strip() or None
    sala        = request.form.get("sala","").strip() or "Geral"
    tipo        = request.form.get("tipo","reserva").strip()
    if tipo not in ("reserva", "interno"):
        tipo = "reserva"
    if tipo == "interno" and sala == "Geral":
        sala = "Evento interno"
    if not titulo or not data_evento:
        flash("Informe titulo e data.", "erro")
        return redirect(url_for("agenda"))
    u = usuario_atual()
    agenda_model.criar_evento(titulo, descricao, data_evento, hora_inicio, hora_fim, sala,
                               u["nome"] if u else "Sistema", tipo)
    flash("Evento adicionado.", "sucesso")
    ano, mes, _ = data_evento.split("-")
    return redirect(url_for("agenda", ano=int(ano), mes=int(mes)))

@app.route("/agenda/<int:eid>/editar", methods=["POST"])
@recepcao_required
def agenda_editar(eid):
    titulo      = request.form.get("titulo","").strip()
    descricao   = request.form.get("descricao","").strip()
    data_evento = request.form.get("data","").strip()
    hora_inicio = request.form.get("hora_inicio","").strip() or None
    hora_fim    = request.form.get("hora_fim","").strip() or None
    sala        = request.form.get("sala","").strip() or "Geral"
    tipo        = request.form.get("tipo","reserva").strip()
    if tipo not in ("reserva", "interno"):
        tipo = "reserva"
    if tipo == "interno" and sala == "Geral":
        sala = "Evento interno"
    agenda_model.atualizar_evento(eid, titulo, descricao, data_evento, hora_inicio, hora_fim, sala, tipo)
    flash("Evento atualizado.", "sucesso")
    ano, mes, _ = data_evento.split("-")
    return redirect(url_for("agenda", ano=int(ano), mes=int(mes)))

@app.route("/agenda/<int:eid>/excluir", methods=["POST"])
@recepcao_required
def agenda_excluir(eid):
    agenda_model.excluir_evento(eid)
    flash("Evento removido.", "sucesso")
    return redirect(url_for("agenda"))

@app.route("/api/agenda/evento/<int:eid>")
def api_agenda_evento(eid):
    e = agenda_model.buscar_evento_por_id(eid)
    if not e: return jsonify(erro="Não encontrado."), 404
    return jsonify(dict(e))

# ── RESERVAS ─────────────────────────────────────────────
@app.route("/reservas", methods=["GET","POST"])
def reservas():
    if request.method == "GET":
        return redirect(url_for("agenda"))

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    if request.method == "POST":
        sala_nome   = request.form.get("sala","").strip()
        titulo      = request.form.get("titulo","").strip()
        data_r      = request.form.get("data","").strip()
        hi          = request.form.get("hora_inicio","").strip()
        hf          = request.form.get("hora_fim","").strip()
        responsavel = request.form.get("responsavel","").strip()
        obs         = request.form.get("observacao","").strip()

        if not all([sala_nome, titulo, data_r, hi, hf, responsavel]):
            flash("Preencha todos os campos obrigatórios.", "erro")
            conn.close(); return redirect(url_for("agenda"))
        if hf <= hi:
            flash("Hora final deve ser depois da inicial.", "erro")
            conn.close(); return redirect(url_for("agenda"))

        cursor.execute("SELECT id FROM salas WHERE nome=?", (sala_nome,))
        sala = cursor.fetchone()
        sala_id = sala["id"] if sala else cursor.execute("INSERT INTO salas(nome) VALUES(?)",(sala_nome,)).lastrowid
        conn.commit()

        cursor.execute(
            "SELECT id FROM reservas WHERE sala_id=? AND data_reserva=? AND NOT(hora_fim<=? OR hora_inicio>=?)",
            (sala_id, data_r, hi, hf))
        if cursor.fetchone():
            flash("Já existe reserva nesse horário.", "erro")
            conn.close(); return redirect(url_for("agenda"))

        cursor.execute(
            "INSERT INTO reservas(sala_id,titulo,responsavel,data_reserva,hora_inicio,hora_fim,observacao) VALUES(?,?,?,?,?,?,?)",
            (sala_id, titulo, responsavel, data_r, hi, hf, obs))
        conn.commit()

        # Sincroniza com a agenda automaticamente
        descricao_evento = f"Reserva por {responsavel}" + (f" — {obs}" if obs else "")
        agenda_model.criar_evento(titulo, descricao_evento, data_r, hi, hf, sala_nome, responsavel)

        flash("Reserva criada e adicionada à agenda!", "sucesso")
        conn.close(); return redirect(url_for("agenda"))

    cursor.execute("SELECT nome FROM salas ORDER BY nome")
    salas = [r["nome"] for r in cursor.fetchall()]
    cursor.execute("""SELECT reservas.*,salas.nome AS sala_nome FROM reservas
        JOIN salas ON salas.id=reservas.sala_id
        WHERE date(data_reserva)>=date('now')
        ORDER BY data_reserva,hora_inicio LIMIT 30""")
    lista = cursor.fetchall()
    conn.close()
    return render_template("reservas.html", reservas=lista, salas=salas)

@app.route("/reservas/<int:rid>/excluir", methods=["POST"])
@admin_required
def reservas_excluir(rid):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("DELETE FROM reservas WHERE id=?", (rid,))
    conn.commit(); conn.close()
    flash("Reserva excluída.", "sucesso")
    return redirect(url_for("agenda"))

@app.route("/reservas/<int:rid>/editar", methods=["POST"])
@admin_required
def reservas_editar(rid):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    titulo   = request.form.get("titulo","").strip()
    data_r   = request.form.get("data","").strip()
    hi       = request.form.get("hora_inicio","").strip()
    hf       = request.form.get("hora_fim","").strip()
    resp     = request.form.get("responsavel","").strip()
    obs      = request.form.get("observacao","").strip()
    cursor.execute(
        "UPDATE reservas SET titulo=?,responsavel=?,data_reserva=?,hora_inicio=?,hora_fim=?,observacao=? WHERE id=?",
        (titulo, resp, data_r, hi, hf, obs, rid))
    conn.commit(); conn.close()
    flash("Reserva atualizada.", "sucesso")
    return redirect(url_for("agenda"))

# ── POPS ─────────────────────────────────────────────────
@app.route("/pops")
def pops():
    busca     = request.args.get("q","").strip()
    categoria = request.args.get("cat","").strip()
    lista     = pops_model.listar_pops(busca=busca, categoria=categoria or None)
    return render_template("pops.html", pops=lista, busca=busca,
                           categoria=categoria, categorias=CATEGORIAS_POP)

@app.route("/pops/upload", methods=["POST"])
@admin_required
def pops_upload():
    arquivo   = request.files.get("arquivo")
    titulo    = request.form.get("titulo","").strip()
    categoria = request.form.get("categoria","Outros").strip()
    if categoria not in CATEGORIAS_POP:
        categoria = "Outros"
    if not arquivo or not arquivo.filename:
        flash("Selecione um arquivo.", "erro"); return redirect(url_for("pops"))
    ext = Path(arquivo.filename).suffix.lower()
    if ext not in (".pdf",".docx",".txt"):
        flash("Formatos aceitos: PDF, DOCX, TXT.", "erro"); return redirect(url_for("pops"))
    if not titulo:
        titulo = Path(arquivo.filename).stem
    pasta = Path("static/uploads/pops")
    pasta.mkdir(parents=True, exist_ok=True)
    nome_seg = f"{int(time.time())}_{secure_filename(arquivo.filename)}"
    caminho  = pasta / nome_seg
    arquivo.save(caminho)
    texto = pops_model.extrair_texto(caminho, ext)
    pops_model.criar_pop(titulo, categoria, arquivo.filename, str(caminho), texto)
    flash("POP enviado!", "sucesso")
    return redirect(url_for("pops"))

@app.route("/pops/<int:pid>/download")
def pops_download(pid):
    p = pops_model.buscar_pop_por_id(pid)
    if not p: abort(404)
    return send_file(p["caminho_arquivo"], as_attachment=True, download_name=p["nome_arquivo"])

@app.route("/pops/<int:pid>/visualizar")
def pops_visualizar(pid):
    p = pops_model.buscar_pop_por_id(pid)
    if not p: abort(404)
    ext = Path(p["nome_arquivo"]).suffix.lower()
    if ext == ".pdf":
        return send_file(p["caminho_arquivo"], mimetype="application/pdf")
    # TXT / DOCX → mostra o texto extraído
    return render_template("pop_visualizar.html", pop=p)

@app.route("/pops/<int:pid>/excluir", methods=["POST"])
@admin_required
def pops_excluir(pid):
    p = pops_model.buscar_pop_por_id(pid)
    if p:
        try: os.remove(p["caminho_arquivo"])
        except OSError: pass
        pops_model.excluir_pop(pid)
        flash("POP removido.", "sucesso")
    return redirect(url_for("pops"))

# ── HUB DE APPS ──────────────────────────────────────────
@app.route("/apps")
def hub_apps():
    por_setor = hub_model.listar_apps_por_setor_para_usuario(usuario_atual())
    setores   = sorted(por_setor.keys())
    return render_template("hub_apps.html", por_setor=por_setor, setores=setores)

@app.route("/apps/adf")
def app_adf():
    adf_url = os.environ.get("ADF_URL", "").strip()
    if adf_url:
        return redirect(adf_url)
    flash("URL do ADF ainda nao configurada. Ajuste o cadastro em Gerenciar Apps.", "erro")
    return redirect(url_for("hub_apps"))

# ── CHAMADOS E ESTOQUE DE TI ───────────────────────────────
@app.route("/ti/chamados", methods=["GET","POST"])
def chamados_ti():
    u = usuario_atual()
    if request.method == "POST":
        titulo = request.form.get("titulo","").strip()
        descricao = request.form.get("descricao","").strip()
        prioridade = request.form.get("prioridade","normal").strip()
        if not titulo or not descricao:
            flash("Informe titulo e descricao do chamado.", "erro")
            return redirect(url_for("chamados_ti"))
        chamados_model.criar_chamado(u["id"], u["nome"], titulo, descricao, prioridade)
        flash("Chamado registrado. O TI vai acompanhar pela fila.", "sucesso")
        return redirect(url_for("chamados_ti"))

    admin_ti = u and u["role"] in ("admin", "superadmin")
    chamados = chamados_model.listar_chamados(u["id"], admin=admin_ti)
    return render_template(
        "chamados_ti.html",
        chamados=chamados,
        responsaveis=chamados_model.RESPONSAVEIS_TI,
        status_opcoes=chamados_model.STATUS_CHAMADO,
        admin_ti=admin_ti,
        tempo_resposta=chamados_model.tempo_resposta,
        tempo_resolucao=chamados_model.tempo_resolucao,
    )

@app.route("/ti/chamados/<int:chamado_id>/atualizar", methods=["POST"])
@admin_required
def chamados_ti_atualizar(chamado_id):
    responsavel = request.form.get("responsavel","").strip()
    resposta = request.form.get("resposta","").strip()
    status = request.form.get("status","em_atendimento").strip()
    try:
        ok = chamados_model.atualizar_atendimento(chamado_id, responsavel, resposta, status)
    except ValueError:
        ok = False
    flash("Chamado atualizado." if ok else "Nao foi possivel atualizar o chamado.", "sucesso" if ok else "erro")
    return redirect(url_for("chamados_ti"))

@app.route("/ti/chamados/<int:chamado_id>/excluir", methods=["POST"])
@admin_required
def chamados_ti_excluir(chamado_id):
    chamados_model.excluir_chamado(chamado_id)
    flash("Chamado removido.", "sucesso")
    return redirect(url_for("chamados_ti"))

@app.route("/ti/estoque", methods=["GET","POST"])
@admin_required
def estoque_ti():
    if request.method == "POST":
        acao = request.form.get("acao")
        if acao == "criar":
            nome = request.form.get("nome","").strip()
            categoria = request.form.get("categoria","Perifericos").strip()
            quantidade = request.form.get("quantidade", type=int) or 0
            localizacao = request.form.get("localizacao","").strip()
            observacao = request.form.get("observacao","").strip()
            if not nome:
                flash("Informe o nome do item.", "erro")
            else:
                estoque_model.criar_item(nome, categoria, quantidade, localizacao, observacao)
                flash("Item adicionado ao estoque.", "sucesso")
        elif acao == "atualizar":
            estoque_model.atualizar_item(
                request.form.get("item_id", type=int),
                request.form.get("nome",""),
                request.form.get("categoria","Perifericos"),
                request.form.get("quantidade", type=int) or 0,
                request.form.get("localizacao",""),
                request.form.get("observacao",""),
            )
            flash("Item atualizado.", "sucesso")
        elif acao == "excluir":
            estoque_model.excluir_item(request.form.get("item_id", type=int))
            flash("Item removido.", "sucesso")
        return redirect(url_for("estoque_ti"))

    return render_template("estoque_ti.html", itens=estoque_model.listar_itens())

# ── ADMIN APPS (cadastrar/remover cards do hub) ─────────
@app.route("/admin/apps", methods=["GET","POST"])
@admin_required
def admin_apps():
    if request.method == "POST":
        acao = request.form.get("acao")
        if acao == "criar":
            hub_model.criar_app(
                request.form.get("nome",""),
                request.form.get("descricao",""),
                request.form.get("icone","fa-solid fa-mobile-screen"),
                request.form.get("url",""),
                request.form.get("setor","Geral"),
                request.form.get("setores_liberados",""),
            )
            flash("App cadastrado.", "sucesso")
        elif acao == "excluir":
            hub_model.excluir_app(request.form.get("app_id", type=int))
            flash("App removido.", "sucesso")
        elif acao == "toggle":
            hub_model.alternar_ativo(request.form.get("app_id", type=int))
            flash("Status alterado.", "sucesso")
        elif acao == "atualizar":
            hub_model.atualizar_app(
                request.form.get("app_id", type=int),
                request.form.get("nome",""),
                request.form.get("descricao",""),
                request.form.get("icone","fa-solid fa-mobile-screen"),
                request.form.get("url",""),
                request.form.get("setor","Geral"),
                request.form.get("setores_liberados",""),
            )
            flash("App atualizado.", "sucesso")
        return redirect(url_for("admin_apps"))

    todos = hub_model.listar_apps(apenas_ativos=False)
    return render_template("admin_apps.html", apps=todos,
                           setores_conhecidos=["Fiscal","RH","Administrativo","TI","Automações","Comercial","Geral"])

# ── ADMIN ATENDIMENTOS ────────────────────────────────────
@app.route("/admin/atendimentos", methods=["GET", "POST"])
@admin_required
def admin_atendimentos():
    if request.method == "POST":
        arquivo = request.files.get("arquivo")
        if not arquivo or not arquivo.filename:
            flash("Selecione uma planilha XLSX.", "erro")
            return redirect(url_for("admin_atendimentos"))
        ext = Path(arquivo.filename).suffix.lower()
        if ext not in (".xlsx", ".xls"):
            flash("Envie apenas arquivos Excel (.xlsx ou .xls).", "erro")
            return redirect(url_for("admin_atendimentos"))

        pasta = Path("static/uploads/atendimentos")
        pasta.mkdir(parents=True, exist_ok=True)
        nome_seguro = f"{int(time.time())}_{secure_filename(arquivo.filename)}"
        caminho = pasta / nome_seguro
        arquivo.save(caminho)

        try:
            tipo, linhas = atendimentos_model.processar_planilha(caminho)
            atendimentos_model.salvar_metricas(linhas, arquivo.filename, tipo)
            flash(f"Planilha processada: {len(linhas)} colaboradores/departamentos atualizados ({tipo}).", "sucesso")
        except Exception as e:
            flash(f"Nao foi possivel processar a planilha: {e}", "erro")
        return redirect(url_for("admin_atendimentos"))

    return render_template(
        "admin_atendimentos.html",
        metricas=atendimentos_model.listar_metricas(),
        resumo=atendimentos_model.resumo(),
    )

# ── IA ────────────────────────────────────────────────────
@app.route("/ia")
def ia():
    return render_template("ia.html")

@app.route("/api/ia", methods=["POST"])
def api_ia():
    dados    = request.get_json(silent=True) or {}
    pergunta = (dados.get("pergunta") or "").strip()
    if not pergunta:
        return jsonify(sucesso=False, erro="Pergunta vazia."), 400
    pops_rel     = pops_model.buscar_pops_relevantes(pergunta)
    noticias_rel = noticias_model.buscar_noticias_relevantes(pergunta)
    eventos_rel  = agenda_model.buscar_eventos_relevantes(pergunta)
    try:
        resposta = perguntar_ia(pergunta, pops_rel, noticias_rel, eventos_rel)
        fontes   = (
            [f"POP: {p['titulo']}" for p in pops_rel]
            + [f"Notícia: {n['titulo']}" for n in noticias_rel]
            + [f"Agenda: {e['titulo']}" for e in eventos_rel]
        )
        return jsonify(sucesso=True, resposta=resposta, fontes=fontes)
    except Exception as e:
        logging.error(f"IA erro: {e}")
        return jsonify(sucesso=False, erro="Servidor Ollama indisponível."), 500

# ── ACESSOS ──────────────────────────────────────────────
@app.route("/admin/acessos")
@admin_required
def admin_acessos():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    acessos = conn.execute("SELECT * FROM acessos ORDER BY id DESC LIMIT 500").fetchall()
    conn.close()
    logins = []
    p = os.path.join(LOG_DIR,"logins.txt")
    if os.path.exists(p):
        linhas = [l.strip() for l in open(p,encoding="utf-8") if l.strip()]
        logins = list(reversed(linhas[-200:]))
    return render_template("admin_acessos.html", acessos=acessos, logins=logins)

# ── HONEYPOT ──────────────────────────────────────────────
@app.route("/admin/honeypot")
@admin_required
def admin_honeypot():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    resumo_niveis = conn.execute(
        """
        SELECT nivel, COUNT(*) AS total
        FROM honeypot_tentativas
        GROUP BY nivel
        ORDER BY total DESC
        """
    ).fetchall()
    top_ips = conn.execute(
        """
        SELECT ip, pais, COUNT(*) AS total,
               MAX(criado_em) AS ultimo,
               GROUP_CONCAT(DISTINCT nivel) AS niveis
        FROM honeypot_tentativas
        GROUP BY ip, pais
        ORDER BY total DESC, ultimo DESC
        LIMIT 20
        """
    ).fetchall()
    top_rotas = conn.execute(
        """
        SELECT rota, COUNT(*) AS total
        FROM honeypot_tentativas
        GROUP BY rota
        ORDER BY total DESC
        LIMIT 12
        """
    ).fetchall()
    tentativas = conn.execute(
        """
        SELECT *
        FROM honeypot_tentativas
        ORDER BY id DESC
        LIMIT 300
        """
    ).fetchall()
    conn.close()
    return render_template(
        "admin_honeypot.html",
        resumo_niveis=resumo_niveis,
        top_ips=top_ips,
        top_rotas=top_rotas,
        tentativas=tentativas,
    )

# ── USUÁRIOS ─────────────────────────────────────────────
@app.route("/admin/usuarios", methods=["GET","POST"])
@superadmin_required
def admin_usuarios():
    if request.method == "POST":
        acao = request.form.get("acao")
        if acao == "criar":
            nome  = request.form.get("nome","").strip()
            email = request.form.get("email","").strip()
            senha = request.form.get("senha","")
            role  = request.form.get("role","comum")
            setor = request.form.get("setor","").strip()
            if not nome or not email or not senha:
                flash("Preencha nome, e-mail e senha.", "erro")
            elif usuarios_model.buscar_usuario_por_email(email):
                flash("E-mail já cadastrado.", "erro")
            else:
                usuarios_model.criar_usuario(nome, email, senha, role, setor)
                flash("Usuário criado.", "sucesso")
        elif acao == "atualizar_role":
            usuarios_model.atualizar_role(request.form.get("usuario_id",type=int), request.form.get("role"))
            flash("Papel atualizado.", "sucesso")
        elif acao == "alternar_status":
            usuarios_model.atualizar_status(request.form.get("usuario_id",type=int),
                                             request.form.get("ativo")=="1")
            flash("Status atualizado.", "sucesso")
        elif acao == "excluir":
            uid = request.form.get("usuario_id", type=int)
            atual = usuario_atual()
            if atual and uid == atual["id"]:
                flash("Voce nao pode excluir o proprio usuario logado.", "erro")
            else:
                usuarios_model.excluir_usuario(uid)
                flash("Usuario removido.", "sucesso")
        return redirect(url_for("admin_usuarios"))
    return render_template("admin_usuarios.html",
                           usuarios=usuarios_model.listar_usuarios(),
                           papeis=usuarios_model.PAPEIS)

# ── ERROS ────────────────────────────────────────────────
@app.errorhandler(404)
def e404(e): return render_template("erros/404.html"), 404
@app.errorhandler(500)
def e500(e): return render_template("erros/500.html"), 500

# ── STARTUP ──────────────────────────────────────────────
criar_tabelas()
bootstrap_superadmin()
carregar_apps()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

